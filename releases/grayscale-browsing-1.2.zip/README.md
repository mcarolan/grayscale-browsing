Grayscale Browsing
====

A simple Firefox extension that toggles grayscale viewing on individual tabs.

Based on the [Your second WebExtension](https://developer.mozilla.org/en-US/Add-ons/WebExtensions/Your_second_WebExtension) tutorial on [MDN](https://developer.mozilla.org/).

Icon
---

Is from [Aha-Soft's Free Retina iconset](https://www.iconfinder.com/iconsets/free-retina-icon-set)
